﻿using System;
using System.Collections.Generic;
using Npgsql;

namespace ShopApp
{
    class Program
    {
        private const string ConnStr = "Host=localhost;Database=postgres;Username=postgres;Password=password"; // пароль как в колледже

        static void Main()
        {
            Console.WriteLine("Проверка подключения к базе данных...");
            try
            {
                using var testConn = new NpgsqlConnection(ConnStr);
                testConn.Open();
                Console.WriteLine("Подключение успешно.\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
                return;
            }

            while (true)
            {
                ShowMenu();
                string choice = Console.ReadLine()?.Trim();

                try
                {
                    switch (choice)
                    {
                        case "1": ListCustomers(); break;
                        case "2": AddCustomer(); break;
                        case "3": DeleteCustomer(); break;
                        case "4": ListProducts(); break;
                        case "5": AddProduct(); break;
                        case "6": UpdateStock(); break;
                        case "7": ListOrders(); break;
                        case "8": CreateOrder(); break;
                        case "9": ShowRevenue(); break;
                        case "0": Console.WriteLine("Выход."); return;
                        default: Console.WriteLine("Неверный ввод."); break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }

                Console.WriteLine("\nНажмите Enter для продолжения...");
                Console.ReadLine();
                Console.Clear();
            }
        }

        static void ShowMenu()
        {
            Console.WriteLine("=== SHOP DB CONSOLE ===");
            Console.WriteLine("1. Клиенты (список)   2. Добавить клиента   3. Удалить клиента");
            Console.WriteLine("4. Товары (список)    5. Добавить товар     6. Изменить остаток");
            Console.WriteLine("7. Заказы (список)    8. Создать заказ      9. Отчет по выручке");
            Console.WriteLine("0. Выход");
            Console.Write("Выбор: ");
        }

        static void ListCustomers()
        {
            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT customer_id, full_name, email, phone FROM customers ORDER BY customer_id", conn);
            using var reader = cmd.ExecuteReader();

            Console.WriteLine("\nСписок клиентов:");
            Console.WriteLine($"{"ID",-5} {"Имя",-20} {"Email",-25} {"Телефон"}");
            Console.WriteLine(new string('-', 60));

            bool hasData = false;
            while (reader.Read())
            {
                hasData = true;
                Console.WriteLine($"{reader["customer_id"],-5} {reader["full_name"],-20} {reader["email"],-25} {reader["phone"]}");
            }
            if (!hasData) Console.WriteLine("Список пуст.");
        }

        static void AddCustomer()
        {
            Console.Write("Имя: "); string name = Console.ReadLine();
            Console.Write("Email: "); string email = Console.ReadLine();
            Console.Write("Телефон (Enter если нет): "); string phone = Console.ReadLine();

            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand(
                "INSERT INTO customers (full_name, email, phone) VALUES (@n, @e, @p) RETURNING customer_id", conn);
            cmd.Parameters.AddWithValue("n", name);
            cmd.Parameters.AddWithValue("e", email);
            cmd.Parameters.AddWithValue("p", string.IsNullOrWhiteSpace(phone) ? DBNull.Value : phone);

            Console.WriteLine($"Клиент создан. ID: {cmd.ExecuteScalar()}");
        }

        static void DeleteCustomer()
        {
            Console.Write("ID клиента для удаления: ");
            if (!int.TryParse(Console.ReadLine(), out int id)) { Console.WriteLine("Неверный формат"); return; }

            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand("DELETE FROM customers WHERE customer_id = @id", conn);
            cmd.Parameters.AddWithValue("id", id);
            Console.WriteLine(cmd.ExecuteNonQuery() > 0 ? "Клиент удален." : "Клиент не найден.");
        }

        static void ListProducts()
        {
            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT product_id, product_name, category, price, stock FROM products ORDER BY product_id", conn);
            using var reader = cmd.ExecuteReader();

            Console.WriteLine("\nСписок товаров:");
            Console.WriteLine($"{"ID",-5} {"Название",-22} {"Категория",-12} {"Цена",-8} {"Остаток"}");
            Console.WriteLine(new string('-', 65));

            while (reader.Read())
            {
                Console.WriteLine($"{reader["product_id"],-5} {reader["product_name"],-22} {reader["category"],-12} {reader["price"],-8} {reader["stock"]}");
            }
        }

        static void AddProduct()
        {
            Console.Write("Название: "); string name = Console.ReadLine();
            Console.Write("Категория: "); string cat = Console.ReadLine();
            Console.Write("Цена: "); decimal price = decimal.Parse(Console.ReadLine());
            Console.Write("Остаток: "); int stock = int.Parse(Console.ReadLine());

            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand(
                "INSERT INTO products (product_name, category, price, stock) VALUES (@n, @c, @p, @s) RETURNING product_id", conn);
            cmd.Parameters.AddWithValue("n", name);
            cmd.Parameters.AddWithValue("c", cat);
            cmd.Parameters.AddWithValue("p", price);
            cmd.Parameters.AddWithValue("s", stock);

            Console.WriteLine($"Товар создан. ID: {cmd.ExecuteScalar()}");
        }

        static void UpdateStock()
        {
            Console.Write("ID товара: "); int pid = int.Parse(Console.ReadLine());
            Console.Write("Новый остаток: "); int newStock = int.Parse(Console.ReadLine());

            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand("UPDATE products SET stock = @s WHERE product_id = @id", conn);
            cmd.Parameters.AddWithValue("s", newStock);
            cmd.Parameters.AddWithValue("id", pid);
            Console.WriteLine(cmd.ExecuteNonQuery() > 0 ? "Остаток обновлен." : "Товар не найден.");
        }

        static void ListOrders()
        {
            using var connOuter = new NpgsqlConnection(ConnStr);
            connOuter.Open();
            using var cmdOrders = new NpgsqlCommand(@"
                SELECT o.order_id, c.full_name, o.order_date, o.status
                FROM orders o JOIN customers c ON o.customer_id = c.customer_id
                ORDER BY o.order_id", connOuter);
            using var rOrders = cmdOrders.ExecuteReader();

            Console.WriteLine("\nСписок заказов:");
            while (rOrders.Read())
            {
                int oid = (int)rOrders["order_id"];
                Console.WriteLine($"\nЗаказ #{oid} | {rOrders["full_name"]} | {rOrders["order_date"]:dd.MM.yyyy} | {rOrders["status"]}");

                using var connInner = new NpgsqlConnection(ConnStr);
                connInner.Open();
                using var cmdItems = new NpgsqlCommand(@"
                    SELECT p.product_name, oi.quantity, oi.price, oi.quantity * oi.price as subtotal
                    FROM order_items oi JOIN products p ON oi.product_id = p.product_id
                    WHERE oi.order_id = @oid", connInner);
                cmdItems.Parameters.AddWithValue("oid", oid);
                using var rItems = cmdItems.ExecuteReader();

                decimal total = 0;
                while (rItems.Read())
                {
                    decimal sub = (decimal)rItems["subtotal"];
                    total += sub;
                    Console.WriteLine($"   • {rItems["product_name"]}: {rItems["quantity"]} шт x {rItems["price"]} = {sub:F2}");
                }
                Console.WriteLine($"   Итого: {total:F2}");
            }
        }

        static void CreateOrder()
        {
            Console.Write("ID клиента: "); int cid = int.Parse(Console.ReadLine());
            var items = new List<(int ProductId, int Qty)>();

            Console.WriteLine("Добавляйте товары (ID Кол-во). Пустая строка для завершения:");
            while (true)
            {
                string line = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(line)) break;
                var parts = line.Split(' ');
                if (parts.Length == 2 && int.TryParse(parts[0], out int pid) && int.TryParse(parts[1], out int qty))
                    items.Add((pid, qty));
                else
                    Console.WriteLine("Неверный формат. Используйте: <ID> <Кол-во>");
            }

            if (items.Count == 0) { Console.WriteLine("Нет товаров для заказа."); return; }

            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                using var cmdOrder = new NpgsqlCommand("INSERT INTO orders (customer_id, status) VALUES (@cid, 'new') RETURNING order_id", conn, tx);
                cmdOrder.Parameters.AddWithValue("cid", cid);
                int orderId = (int)cmdOrder.ExecuteScalar();

                foreach (var (pid, qty) in items)
                {
                    decimal price;
                    int stock;

                    using (var cmdCheck = new NpgsqlCommand("SELECT price, stock FROM products WHERE product_id = @pid", conn, tx))
                    {
                        cmdCheck.Parameters.AddWithValue("pid", pid);
                        using (var r = cmdCheck.ExecuteReader())
                        {
                            if (!r.Read()) throw new Exception($"Товар #{pid} не найден");
                            price = r.GetDecimal(0);
                            stock = r.GetInt32(1);
                        }
                    }

                    if (stock < qty) throw new Exception($"Недостаточно товара #{pid} (доступно {stock})");

                    using var cmdItem = new NpgsqlCommand(
                        "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (@oid, @pid, @qty, @price)", conn, tx);
                    cmdItem.Parameters.AddWithValue("oid", orderId);
                    cmdItem.Parameters.AddWithValue("pid", pid);
                    cmdItem.Parameters.AddWithValue("qty", qty);
                    cmdItem.Parameters.AddWithValue("price", price);
                    cmdItem.ExecuteNonQuery();

                    using var cmdStock = new NpgsqlCommand("UPDATE products SET stock = stock - @qty WHERE product_id = @pid", conn, tx);
                    cmdStock.Parameters.AddWithValue("qty", qty);
                    cmdStock.Parameters.AddWithValue("pid", pid);
                    cmdStock.ExecuteNonQuery();
                }

                tx.Commit();
                Console.WriteLine($"Заказ #{orderId} успешно создан.");
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        static void ShowRevenue()
        {
            using var conn = new NpgsqlConnection(ConnStr);
            conn.Open();
            using var cmd = new NpgsqlCommand(@"
                SELECT o.order_id, c.full_name, SUM(oi.quantity * oi.price) as total
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                JOIN order_items oi ON o.order_id = oi.order_id
                GROUP BY o.order_id, c.full_name
                ORDER BY o.order_id", conn);
            using var reader = cmd.ExecuteReader();

            Console.WriteLine("\nОтчет по выручке:");
            Console.WriteLine($"{"Заказ",-8} {"Клиент",-20} {"Сумма"}");
            Console.WriteLine(new string('-', 40));

            decimal grandTotal = 0;
            while (reader.Read())
            {
                decimal total = reader.GetDecimal(2);
                grandTotal += total;
                Console.WriteLine($"{reader["order_id"],-8} {reader["full_name"],-20} {total:F2}");
            }
            Console.WriteLine(new string('-', 40));
            Console.WriteLine($"ИТОГО: {grandTotal:F2}");
        }
    }
}